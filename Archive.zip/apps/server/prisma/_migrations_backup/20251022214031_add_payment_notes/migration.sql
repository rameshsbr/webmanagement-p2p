-- AlterTable
ALTER TABLE "PaymentRequest" ADD COLUMN     "notes" TEXT;
