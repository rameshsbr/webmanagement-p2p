-- AlterTable
ALTER TABLE "BankAccount" ADD COLUMN     "fields" JSONB;
