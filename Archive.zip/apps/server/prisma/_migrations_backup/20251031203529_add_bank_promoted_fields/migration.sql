-- AlterTable
ALTER TABLE "BankAccount" ADD COLUMN     "bsb" TEXT;
