/*
  Warnings:

  - You are about to drop the column `bsb` on the `BankAccount` table. All the data in the column will be lost.

*/
-- AlterTable
ALTER TABLE "BankAccount" DROP COLUMN "bsb";
