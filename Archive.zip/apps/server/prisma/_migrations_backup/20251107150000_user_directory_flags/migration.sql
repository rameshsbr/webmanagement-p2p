ALTER TABLE "Merchant"
ADD COLUMN "userDirectoryEnabled" BOOLEAN NOT NULL DEFAULT false;
