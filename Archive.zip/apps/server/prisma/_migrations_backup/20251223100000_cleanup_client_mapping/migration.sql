-- Drop redundant MerchantClient table now that MerchantClientMapping is canonical
DROP TABLE "MerchantClient";
