// apps/server/src/routes/admin.ts
import { Router, Request, Response } from 'express';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { prisma } from '../lib/prisma.js';
import { z } from 'zod';
import { stringify } from 'csv-stringify';
import ExcelJS from 'exceljs';
import { getUserDirectory, getAllUsers, UserDirectoryItem, renderUserDirectoryPdf } from '../services/userDirectory.js';
import { changePaymentStatus, evaluateNameMatch, PaymentStatusError } from '../services/paymentStatus.js';
import {
  buildPaymentExportFile,
  normalizeColumns,
  PaymentExportColumn,
  PaymentExportItem,
} from '../services/paymentExports.js';
import { normalizeTimezone, resolveTimezone } from '../lib/timezone.js';
import { formatClientStatusLabel } from '../services/merchantClient.js';

async function safeNotify(text: string) {
  try {
    const mod = await import('../services/telegram.js' as any);
    const svc: any = mod;
    if (typeof svc?.send === 'function') return svc.send(text);
    if (typeof svc?.sendMessage === 'function') return svc.sendMessage(text);
  } catch {}
}

function adminCanViewUsers(req: Request): boolean {
  const session: any = (req as any).admin || null;
  if (session && typeof session.canViewUsers === 'boolean') {
    return session.canViewUsers;
  }

  if (typeof (req as any).adminCanViewUsers === 'boolean') {
    return !!(req as any).adminCanViewUsers;
  }

  const details: any = (req as any).adminDetails || null;
  if (details && typeof details.canViewUserDirectory === 'boolean') {
    const allowed = details.canViewUserDirectory !== false;
    if (session && typeof session.canViewUsers !== 'boolean') {
      session.canViewUsers = allowed;
    }
    return allowed;
  }

  return true;
}

const router = Router();

const CURRENT_DIR = path.dirname(fileURLToPath(import.meta.url));
const ADMIN_PUBLIC_DIR = path.join(CURRENT_DIR, '../public/admin');

const ADMIN_DEPOSIT_EXPORT_COLUMNS: PaymentExportColumn[] = [
  { key: 'txnId', label: 'TRANSACTION ID' },
  { key: 'userId', label: 'USER ID' },
  { key: 'merchant', label: 'MERCHANT' },
  { key: 'currency', label: 'CURRENCY' },
  { key: 'amount', label: 'AMOUNT' },
  { key: 'status', label: 'STATUS' },
  { key: 'bank', label: 'BANK NAME' },
  { key: 'created', label: 'DATE OF CREATION' },
  { key: 'processedAt', label: 'DATE OF DEPOSIT' },
  { key: 'processingTime', label: 'TIME TO PROCESS' },
  { key: 'userInfo', label: 'USER INFO' },
  { key: 'comment', label: 'COMMENT' },
  { key: 'admin', label: 'ADMIN' },
  { key: 'actions', label: 'ACTIONS' },
];

const ADMIN_WITHDRAWAL_EXPORT_COLUMNS: PaymentExportColumn[] = [
  { key: 'txnId', label: 'TRANSACTION ID' },
  { key: 'userId', label: 'USER ID' },
  { key: 'merchant', label: 'MERCHANT' },
  { key: 'currency', label: 'CURRENCY' },
  { key: 'amount', label: 'AMOUNT' },
  { key: 'status', label: 'STATUS' },
  { key: 'bank', label: 'BANK NAME' },
  { key: 'created', label: 'DATE OF CREATION' },
  { key: 'processedAt', label: 'DATE OF WITHDRAWAL' },
  { key: 'processingTime', label: 'TIME TO PROCESS' },
  { key: 'userInfo', label: 'USER INFO' },
  { key: 'comment', label: 'COMMENT' },
  { key: 'admin', label: 'ADMIN' },
  { key: 'actions', label: 'ACTIONS' },
];

function extractHolderName(details: any, type: 'DEPOSIT' | 'WITHDRAWAL'): string | null {
  if (!details || typeof details !== 'object') return null;
  const payer = (details as any).payer || {};
  const destination = (details as any).destination || {};

  const holderName =
    type === 'DEPOSIT'
      ? payer.holderName || destination.holderName || null
      : destination.holderName || payer.holderName || null;

  return typeof holderName === 'string' && holderName.trim().length ? holderName.trim() : null;
}

router.get('/queue-sw.js', (_req, res) => {
  res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate');
  res.setHeader('Service-Worker-Allowed', '/admin/');
  res.sendFile(path.join(ADMIN_PUBLIC_DIR, 'queue-sw.js'));
});

router.post('/prefs/timezone', async (req: any, res) => {
  const adminId = req.admin?.sub ? String(req.admin.sub) : null;
  if (!adminId) {
    return res.status(401).json({ ok: false, error: 'Not authenticated' });
  }

  const timezoneRaw = normalizeTimezone(req.body?.timezone);
  const timezone = timezoneRaw ?? null;

  try {
    await prisma.adminUser.update({
      where: { id: adminId },
      data: { timezone },
    });
    const resolved = resolveTimezone(timezone);
    res.locals.timezone = resolved;
    (req as any).activeTimezone = resolved;
    if (req.admin && typeof req.admin === 'object') {
      req.admin.timezone = resolved;
    }
    return res.json({ ok: true, timezone: resolved });
  } catch (err) {
    console.error('[admin prefs] failed to update timezone', err);
    return res.status(500).json({ ok: false, error: 'Failed to save timezone' });
  }
});

// ───────────────────────────────────────────────────────────────────────────────
// Helpers
// ───────────────────────────────────────────────────────────────────────────────
function int(v: any, d: number) { const n = Number(v); return Number.isFinite(n) ? n : d; }

function statusesCSV(s?: string) {
  if (!s) return undefined;
  const ok = new Set(['PENDING','SUBMITTED','APPROVED','REJECTED']);
  const arr = s.split(',').map(x=>x.trim().toUpperCase()).filter(x=>ok.has(x));
  return arr.length ? arr : undefined;
}

function formatAmount(cents: number) {
  if (typeof cents !== 'number' || !Number.isFinite(cents)) return '-';
  const absCents = Math.abs(cents);
  const hasFraction = absCents % 100 !== 0;
  const value = (cents / 100).toLocaleString('en-AU', {
    minimumFractionDigits: hasFraction ? 2 : 0,
    maximumFractionDigits: hasFraction ? 2 : 0,
  });
  return value;
}

function sortSpec(s?: string) {
  const wl = new Set(['createdAt','processedAt','updatedAt','amountCents','status','currency','referenceCode']);
  let col: string = 'createdAt', dir: 'asc'|'desc' = 'desc';
  if (s) {
    const [c, d] = s.split(':');
    if (c && wl.has(c)) col = c;
    if (d === 'asc' || d === 'desc') dir = d;
  }
  return { [col]: dir } as any;
}

function bankLabel(bank?: { publicId?: string | null; bankName?: string | null } | null) {
  if (!bank) return '';
  const parts: string[] = [];
  if (bank.publicId) parts.push(bank.publicId);
  if (bank.bankName) parts.push(bank.bankName);
  return parts.join(' • ');
}

const userDirectoryQuery = z.object({
  q: z.string().optional(),
  merchantId: z.string().optional(),
  page: z.string().optional(),
  perPage: z.string().optional(),
});

async function resolveUserDirectoryInput(req: Request) {
  const query = userDirectoryQuery.parse(req.query);
  const merchants = await prisma.merchant.findMany({
    where: { userDirectoryEnabled: true },
    select: { id: true, name: true },
    orderBy: { name: 'asc' },
  });
  const allowedIds = merchants.map((m) => m.id);
  const selected = query.merchantId && allowedIds.includes(query.merchantId)
    ? [query.merchantId]
    : allowedIds;
  return { query, merchants, merchantIds: selected };
}

async function collectUsersForExport(merchantIds: string[], search?: string | null) {
  if (!merchantIds.length) return [] as UserDirectoryItem[];
  return getAllUsers({ merchantIds, search: search ?? null });
}

const listQuery = z.object({
  q: z.string().optional(),
  reference: z.string().optional(),
  uniqueReference: z.string().optional(),
  id: z.string().optional(),
  userId: z.string().optional(),
  merchantId: z.string().optional(),
  merchantName: z.string().optional(),
  processedBy: z.string().optional(),
  processedByName: z.string().optional(),
  currency: z.string().optional(),
  status: z.string().optional(),
  bankId: z.string().optional(),
  method: z.string().optional(),
  amountMin: z.string().optional(),
  amountMax: z.string().optional(),
  from: z.string().optional(),
  to: z.string().optional(),
  dateField: z.enum(['createdAt','processedAt','updatedAt']).optional(),
  sort: z.string().optional(),
  page: z.string().optional(),
  perPage: z.string().optional()
});

const LIST_QUERY_KEYS = new Set(Object.keys((listQuery as any).shape || {}));

function whereFrom(q: z.infer<typeof listQuery>, type: 'DEPOSIT' | 'WITHDRAWAL') {
  const where: any = { type };
  const and: any[] = [];
  if (q.id) where.id = q.id;
  if (q.reference) where.referenceCode = q.reference;
  if (q.uniqueReference) where.uniqueReference = q.uniqueReference;
  if (q.userId) {
    and.push({
      OR: [
        { user: { publicId: { equals: q.userId } } },
        { userId: q.userId }
      ]
    });
  }
  if (q.merchantId) where.merchantId = q.merchantId;
  if (q.merchantName) {
    and.push({ merchant: { name: { contains: q.merchantName, mode: 'insensitive' } } });
  }
  if (q.currency) where.currency = q.currency;
  if (q.bankId) {
    and.push({
      OR: [
        { bankAccountId: q.bankId },
        { bankAccount: { publicId: q.bankId } }
      ]
    });
  }
  if (q.processedBy) where.processedByAdminId = q.processedBy;
  if (q.processedByName) {
    and.push({
      processedByAdmin: {
        OR: [
          { displayName: { contains: q.processedByName, mode: 'insensitive' } },
          { email: { contains: q.processedByName, mode: 'insensitive' } }
        ]
      }
    });
  }
  const sts = statusesCSV(q.status);
  if (sts) where.status = { in: sts };
  if (q.amountMin || q.amountMax) {
    where.amountCents = {};
    if (q.amountMin) {
      const v = Number(q.amountMin);
      if (Number.isFinite(v)) where.amountCents.gte = Math.round(v * 100);
    }
    if (q.amountMax) {
      const v = Number(q.amountMax);
      if (Number.isFinite(v)) where.amountCents.lte = Math.round(v * 100);
    }
  }
  const df = q.dateField || 'createdAt';
  if (q.from || q.to) {
    where[df] = {};
    if (q.from) where[df].gte = new Date(q.from);
    if (q.to) where[df].lte = new Date(q.to);
  }
  if (q.method) {
    and.push({ detailsJson: { path: ['method'], equals: q.method } });
  }
  if (q.q) {
    where.OR = [
      { referenceCode: { contains: q.q, mode: 'insensitive' } },
      { uniqueReference: { contains: q.q, mode: 'insensitive' } },
      { userId: { contains: q.q, mode: 'insensitive' } }
    ];
  }
  if (and.length) {
    where.AND = (where.AND || []).concat(and);
  }
  return where;
}

type ListQuery = z.infer<typeof listQuery>;

async function fetchPaymentsFromQuery(
  input: Partial<ListQuery>,
  type: 'DEPOSIT' | 'WITHDRAWAL'
) {
  const q = listQuery.parse(input);
  const where = whereFrom(q, type);
  const page = Math.max(1, int(q.page, 1));
  const perPage = Math.min(150, Math.max(5, int(q.perPage, 25)));
  const orderBy = sortSpec(q.sort);

  const [total, itemsRaw] = await Promise.all([
    prisma.paymentRequest.count({ where }),
    prisma.paymentRequest.findMany({
      where,
      distinct: ['id'],
      include: {
        merchant: { select: { id: true, name: true } },
        user: { select: { id: true, publicId: true, email: true, phone: true, diditSubject: true, fullName: true, firstName: true, lastName: true } },
        bankAccount: {
          select: {
            id: true,
            publicId: true,
            bankName: true,
            holderName: true,
            accountNo: true,
            currency: true,
            method: true,
          }
        },
        receiptFile: { select: { id: true, path: true, mimeType: true, original: true } },
        processedByAdmin: { select: { id: true, email: true, displayName: true } }
      },
      orderBy,
      skip: (page - 1) * perPage,
      take: perPage
    })
  ]);

  const items: typeof itemsRaw = [];
  const seen = new Set<string>();
  for (const item of itemsRaw) {
    if (seen.has(item.id)) continue;
    seen.add(item.id);
    items.push(item);
  }

  const itemsWithFlags = items.map((item) => {
    const details = (item as any).detailsJson;
    const holderName = extractHolderName(details, item.type as 'DEPOSIT' | 'WITHDRAWAL');
    const user = (item as any).user;
    const match = evaluateNameMatch(
      holderName,
      user?.firstName,
      user?.lastName,
      user?.fullName,
    );

    return {
      ...item,
      nameMatchScore: match.score,
      nameMismatchWarning: match.needsReview,
      nameHardMismatch: !match.allow,
    } as typeof item & {
      nameMatchScore: number;
      nameMismatchWarning: boolean;
      nameHardMismatch: boolean;
    };
  });

  return { total, items: itemsWithFlags, page, perPage, pages: Math.max(1, Math.ceil(total / perPage)), query: q };
}

async function fetchPayments(
  req: Request,
  type: 'DEPOSIT'|'WITHDRAWAL',
  overrides?: Partial<Record<keyof ListQuery, string | undefined>>
) {
  const q = { ...req.query, ...(overrides || {}) } as Partial<ListQuery>;
  return fetchPaymentsFromQuery(q, type);
}

function parseExportFormat(raw: unknown): 'csv' | 'xlsx' | 'pdf' {
  const value = String(raw || '').toLowerCase();
  if (value === 'csv' || value === 'xlsx' || value === 'pdf') return value;
  return 'csv';
}

function coerceExportFilters(raw: unknown): Partial<ListQuery> {
  if (!raw || typeof raw !== 'object') return {};
  const out: Partial<ListQuery> = {};
  for (const key of LIST_QUERY_KEYS) {
    const value = (raw as Record<string, unknown>)[key];
    if (typeof value === 'undefined' || value === null) continue;
    if (typeof value === 'string') {
      (out as any)[key] = value;
    } else if (Array.isArray(value)) {
      const last = value[value.length - 1];
      if (typeof last === 'string') (out as any)[key] = last;
    } else {
      (out as any)[key] = String(value);
    }
  }
  return out;
}

function sanitizeColumns(raw: unknown, fallback: PaymentExportColumn[]): PaymentExportColumn[] {
  const allowed = new Set(fallback.map((col) => col.key));
  return normalizeColumns(raw, fallback, allowed);
}

function resolveReturnTo(raw: unknown, fallback: string) {
  if (typeof raw === 'string' && raw.startsWith('/admin')) return raw;
  return fallback;
}

function extractProcessingDetails(pr: {
  createdAt: Date;
  updatedAt: Date;
  processedAt?: Date | null;
  processedByAdmin?: { displayName: string | null; email: string | null; id: string } | null;
}) {
  const processed = pr.processedAt ?? pr.updatedAt ?? null;
  const processedDate = processed ? new Date(processed) : null;
  const processingSeconds = processedDate
    ? Math.max(0, Math.round((processedDate.getTime() - pr.createdAt.getTime()) / 1000))
    : null;
  const processedBy = pr.processedByAdmin
    ? pr.processedByAdmin.displayName || pr.processedByAdmin.email || pr.processedByAdmin.id
    : '';
  return { processedDate, processingSeconds, processedBy };
}

function readAmountInput(body: unknown): { cents: number | null; provided: boolean; error?: string } {
  if (!body || typeof body !== 'object') return { cents: null, provided: false };
  const payload = body as Record<string, unknown>;

  const normalize = (value: unknown, multiplier: number) => {
    const raw = String(value ?? '').trim();
    if (!raw) return { cents: null, provided: false, error: 'Invalid amount' as const };
    const parsed = Number(raw.replace(/,/g, ''));
    if (!Number.isFinite(parsed) || parsed <= 0) {
      return { cents: null, provided: false, error: 'Invalid amount' as const };
    }
    const cents = Math.round(parsed * multiplier);
    if (!Number.isFinite(cents) || cents <= 0) {
      return { cents: null, provided: false, error: 'Invalid amount' as const };
    }
    return { cents, provided: true };
  };

  if (payload.amount !== undefined && payload.amount !== null) {
    const result = normalize(payload.amount, 100);
    return result.error ? { cents: null, provided: false, error: result.error } : result;
  }

  if (payload.amountCents !== undefined && payload.amountCents !== null) {
    const raw = String(payload.amountCents ?? '').trim();
    if (!raw) return { cents: null, provided: false, error: 'Invalid amount' };
    const parsed = Number(raw.replace(/,/g, ''));
    if (!Number.isFinite(parsed) || parsed <= 0) {
      return { cents: null, provided: false, error: 'Invalid amount' };
    }
    const cents = Math.round(parsed);
    if (!Number.isFinite(cents) || cents <= 0) {
      return { cents: null, provided: false, error: 'Invalid amount' };
    }
    return { cents, provided: true };
  }

  return { cents: null, provided: false };
}

// ───────────────────────────────────────────────────────────────────────────────
// Dashboard
// ───────────────────────────────────────────────────────────────────────────────
router.get('/', async (_req, res) => {
  const awaitingStatuses: Array<'PENDING' | 'SUBMITTED'> = ['PENDING', 'SUBMITTED'];
  const [pendingDeposits, pendingWithdrawals, totalsToday] = await Promise.all([
    prisma.paymentRequest.count({ where: { type: 'DEPOSIT', status: { in: awaitingStatuses } } }),
    prisma.paymentRequest.count({ where: { type: 'WITHDRAWAL', status: { in: awaitingStatuses } } }),
    prisma.paymentRequest.groupBy({
      by: ['type'],
      where: { createdAt: { gte: new Date(new Date().setHours(0,0,0,0)) }, status: 'APPROVED' },
      _sum: { amountCents: true }
    })
  ]);
  res.render('admin-dashboard', {
    title: 'Admin Dashboard',
    metrics: {
      pendingDeposits,
      pendingWithdrawals,
      todayDeposits: totalsToday.find(t => t.type === 'DEPOSIT')?._sum.amountCents ?? 0,
      todayWithdrawals: totalsToday.find(t => t.type === 'WITHDRAWAL')?._sum.amountCents ?? 0
    }
  });
});

/* ---------------- Deposits ---------------- */
router.get('/report/deposits', async (req, res) => {
  const { total, items, page, perPage, pages, query } = await fetchPayments(req, 'DEPOSIT');
  res.render('admin-deposits', { title: 'Deposit requests', table: { total, items, page, perPage, pages }, query });
});

// DB-level filtering for PENDING so new items appear immediately
router.get('/report/deposits/pending', async (req, res) => {
  const { total, items, page, perPage, pages, query } = await fetchPayments(req, 'DEPOSIT', { status: 'PENDING,SUBMITTED' });
  res.render('admin-deposits-pending', {
    title: 'Pending deposit requests',
    table: { total, items, page, perPage, pages },
    query,
    returnTo: req.originalUrl
  });
});

router.get('/notifications/queue', async (req, res) => {
  const parseSinceParam = (value: unknown): Date | null => {
    if (!value) return null;
    const raw = Array.isArray(value) ? value[0] : value;
    if (raw === undefined || raw === null) return null;
    if (raw instanceof Date && !Number.isNaN(raw.getTime())) return raw;
    const numeric = Number(raw);
    if (Number.isFinite(numeric) && numeric > 0) {
      const candidate = new Date(numeric);
      if (!Number.isNaN(candidate.getTime())) return candidate;
    }
    if (typeof raw === 'string' && raw.trim()) {
      const candidate = new Date(raw);
      if (!Number.isNaN(candidate.getTime())) return candidate;
    }
    return null;
  };

  const fallbackSince = parseSinceParam(req.query?.since) ?? new Date();
  const depositsSince =
    parseSinceParam((req.query as Record<string, unknown>)?.sinceDeposits) ??
    parseSinceParam((req.query as Record<string, unknown>)?.depositsSince) ??
    parseSinceParam((req.query as Record<string, unknown>)?.depositSince) ??
    fallbackSince;
  const withdrawalsSince =
    parseSinceParam((req.query as Record<string, unknown>)?.sinceWithdrawals) ??
    parseSinceParam((req.query as Record<string, unknown>)?.withdrawalsSince) ??
    parseSinceParam((req.query as Record<string, unknown>)?.withdrawSince) ??
    fallbackSince;

  const depositWhere = {
    type: 'DEPOSIT' as const,
    status: { in: ['PENDING', 'SUBMITTED'] as Array<'PENDING' | 'SUBMITTED'> },
    OR: [
      { createdAt: { gt: depositsSince } },
      { updatedAt: { gt: depositsSince } },
    ],
  };

  const withdrawalWhere = {
    type: 'WITHDRAWAL' as const,
    status: { in: ['PENDING', 'SUBMITTED'] as Array<'PENDING' | 'SUBMITTED'> },
    OR: [
      { createdAt: { gt: withdrawalsSince } },
      { updatedAt: { gt: withdrawalsSince } },
    ],
  };

  const [deposits, withdrawals, latestDeposit, latestWithdrawal] = await Promise.all([
    prisma.paymentRequest.count({ where: depositWhere }),
    prisma.paymentRequest.count({ where: withdrawalWhere }),
    prisma.paymentRequest.findFirst({
      where: depositWhere,
      orderBy: { updatedAt: 'desc' },
      select: { createdAt: true, updatedAt: true },
    }),
    prisma.paymentRequest.findFirst({
      where: withdrawalWhere,
      orderBy: { updatedAt: 'desc' },
      select: { createdAt: true, updatedAt: true },
    }),
  ]);

  const latestDepositDate = latestDeposit?.updatedAt || latestDeposit?.createdAt || null;
  const latestWithdrawalDate = latestWithdrawal?.updatedAt || latestWithdrawal?.createdAt || null;
  const latestCandidates = [latestDepositDate, latestWithdrawalDate].filter((d): d is Date => !!d);
  const latest = latestCandidates.length
    ? new Date(Math.max(...latestCandidates.map((d) => d.getTime())))
    : null;

  res.json({
    ok: true,
    deposits,
    withdrawals,
    latest,
    latestDeposit: latestDepositDate,
    latestWithdrawal: latestWithdrawalDate,
  });
});

const approveBodySchema = z.object({
  amount: z.union([z.string(), z.number()]).optional(),
  amountCents: z.union([z.string(), z.number()]).optional(),
  comment: z.string().optional(),
  returnTo: z.string().optional()
});

const rejectBodySchema = z.object({
  comment: z.string().optional(),
  reason: z.string().optional(),
  returnTo: z.string().optional()
});

const withdrawApproveSchema = z.object({
  bankAccountId: z.string().trim().min(1),
  returnTo: z.string().optional(),
});

const statusChangeSchema = z.object({
  targetStatus: z.enum(['APPROVED', 'REJECTED']),
  comment: z.string().optional(),
  amount: z.union([z.string(), z.number()]).optional(),
  amountCents: z.union([z.string(), z.number()]).optional(),
});

router.post('/deposits/:id/approve', async (req, res) => {
  const id = req.params.id;
  const pr = await prisma.paymentRequest.findUnique({ where: { id }, include: { merchant: true } });
  if (!pr || pr.type !== 'DEPOSIT' || !['PENDING', 'SUBMITTED'].includes(pr.status)) {
    return res.status(400).json({ ok: false, error: 'Invalid state' });
  }

  const parsed = approveBodySchema.safeParse(req.body ?? {});
  if (!parsed.success) {
    return res.status(400).json({ ok: false, error: 'Invalid payload' });
  }

  const body = parsed.data;
  const amountInfo = readAmountInput(body);
  if (amountInfo.error) {
    return res.status(400).json({ ok: false, error: amountInfo.error });
  }

  const comment = (body.comment || '').trim();
  const nextAmount = amountInfo.provided && amountInfo.cents ? amountInfo.cents : pr.amountCents;
  const amountChanged = amountInfo.provided && amountInfo.cents !== pr.amountCents;
  if (amountChanged && !comment) {
    return res.status(400).json({ ok: false, error: 'Comment required when adjusting the amount' });
  }

  const redirectTarget = resolveReturnTo(body.returnTo, '/admin/report/deposits/pending');
  try {
    const result = await changePaymentStatus('DEPOSIT', {
      paymentId: id,
      targetStatus: 'APPROVED',
      actorAdminId: req.admin?.sub ?? null,
      amountCents: amountInfo.provided ? amountInfo.cents ?? null : null,
      comment,
    });
    const updated = result.payment;
    const suffix = comment ? ` — ${comment}` : '';
    const merchantName = updated.merchant?.name || pr.merchant?.name || updated.merchantId;
    safeNotify(`✅ Deposit approved: ${updated.referenceCode} ${formatAmount(updated.amountCents)} ${updated.currency} (merchant ${merchantName})${suffix}`).catch(() => {});
    res.json({ ok: true, redirect: redirectTarget });
  } catch (err) {
    if (err instanceof PaymentStatusError) {
      return res.status(400).json({ ok: false, error: err.message });
    }
    console.error(err);
    res.status(500).json({ ok: false, error: 'Unable to update status' });
  }
});

router.post('/deposits/:id/reject', async (req, res) => {
  const id = req.params.id;
  const parsed = rejectBodySchema.safeParse(req.body ?? {});
  if (!parsed.success) {
    return res.status(400).json({ ok: false, error: 'Invalid payload' });
  }

  const comment = (parsed.data.comment || parsed.data.reason || '').trim();
  if (!comment) {
    return res.status(400).json({ ok: false, error: 'Comment is required' });
  }

  const pr = await prisma.paymentRequest.findUnique({ where: { id }, include: { merchant: true } });
  if (!pr || pr.type !== 'DEPOSIT' || !['PENDING', 'SUBMITTED'].includes(pr.status)) {
    return res.status(400).json({ ok: false, error: 'Invalid state' });
  }

  const redirectTarget = resolveReturnTo(parsed.data.returnTo, '/admin/report/deposits/pending');
  try {
    const result = await changePaymentStatus('DEPOSIT', {
      paymentId: id,
      targetStatus: 'REJECTED',
      actorAdminId: req.admin?.sub ?? null,
      comment,
    });
    const updated = result.payment;
    const merchantName = updated.merchant?.name || pr.merchant?.name || updated.merchantId;
    safeNotify(`⛔ Deposit rejected: ${updated.referenceCode} ${formatAmount(updated.amountCents)} ${updated.currency} — ${comment}`).catch(() => {});
    res.json({ ok: true, redirect: redirectTarget });
  } catch (err) {
    if (err instanceof PaymentStatusError) {
      return res.status(400).json({ ok: false, error: err.message });
    }
    console.error(err);
    res.status(500).json({ ok: false, error: 'Unable to update status' });
  }
});

router.post('/deposits/:id/status', async (req, res) => {
  const id = req.params.id;
  const parsed = statusChangeSchema.safeParse(req.body ?? {});
  if (!parsed.success) {
    return res.status(400).json({ ok: false, error: 'Invalid payload' });
  }

  const payload = parsed.data;
  const payment = await prisma.paymentRequest.findUnique({ where: { id }, include: { merchant: true } });
  if (!payment || payment.type !== 'DEPOSIT') {
    return res.status(404).json({ ok: false, error: 'Payment not found' });
  }

  const comment = (payload.comment || '').trim();
  const amountInfo = readAmountInput(payload);
  if (amountInfo.error) {
    return res.status(400).json({ ok: false, error: amountInfo.error });
  }

  if (payload.targetStatus === 'REJECTED' && !comment) {
    return res.status(400).json({ ok: false, error: 'Comment is required' });
  }

  if (payload.targetStatus === 'APPROVED') {
    const amountChanged = amountInfo.provided && amountInfo.cents !== payment.amountCents;
    if (amountChanged && !comment) {
      return res.status(400).json({ ok: false, error: 'Comment required when adjusting the amount' });
    }
  }

  try {
    const result = await changePaymentStatus('DEPOSIT', {
      paymentId: id,
      targetStatus: payload.targetStatus,
      actorAdminId: req.admin?.sub ?? null,
      amountCents: payload.targetStatus === 'APPROVED'
        ? (amountInfo.provided ? amountInfo.cents ?? null : null)
        : null,
      comment,
    });
    const updated = result.payment;
    const merchantName = updated.merchant?.name || payment.merchant?.name || updated.merchantId;
    const prefix = payload.targetStatus === 'APPROVED' ? '✅' : '⛔';
    const verb = payload.targetStatus === 'APPROVED' ? 'approved' : 'rejected';
    const suffix = comment ? ` — ${comment}` : '';
    safeNotify(`${prefix} Deposit ${verb}: ${updated.referenceCode} ${formatAmount(updated.amountCents)} ${updated.currency} (merchant ${merchantName})${suffix}`).catch(() => {});
    res.json({ ok: true, status: updated.status, amountCents: updated.amountCents });
  } catch (err) {
    if (err instanceof PaymentStatusError) {
      const message = err.code === 'INSUFFICIENT_FUNDS' ? 'Insufficient Balance' : err.message;
      return res.status(400).json({ ok: false, error: message });
    }
    console.error(err);
    res.status(500).json({ ok: false, error: 'Unable to update status' });
  }
});

router.post('/export/deposits', async (req: Request, res: Response) => {
  try {
    const format = parseExportFormat(req.body?.type);
    const filters = coerceExportFilters(req.body?.filters);
    const columns = sanitizeColumns(req.body?.columns, ADMIN_DEPOSIT_EXPORT_COLUMNS);
    const { items } = await fetchPaymentsFromQuery(filters, 'DEPOSIT');
    const timezone = resolveTimezone((req as any).activeTimezone || res.locals.timezone);
    const file = await buildPaymentExportFile({
      format,
      columns,
      items: items as unknown as PaymentExportItem[],
      context: { scope: 'admin', type: 'DEPOSIT' },
      timezone,
    });
    res.setHeader('Content-Type', file.contentType);
    res.setHeader('Content-Disposition', `attachment; filename="${file.filename}"`);
    res.send(file.body);
  } catch (err) {
    console.error(err);
    res.status(500).json({ ok: false, error: 'Unable to export deposits' });
  }
});

router.get('/export/deposits.csv', async (req: Request, res: Response) => {
  const { items } = await fetchPayments(req, 'DEPOSIT');
  res.setHeader('Content-Type', 'text/csv');
  res.setHeader('Content-Disposition', 'attachment; filename="deposits.csv"');
  const csv = stringify({
    header: true,
    columns: ['id','referenceCode','uniqueReference','userId','merchant','currency','amount','status','bank','createdAt','processedAt','processingSeconds','processedBy','receipt']
  });
  csv.pipe(res);
  for (const x of items) {
    const { processedDate, processingSeconds, processedBy } = extractProcessingDetails(x);
    csv.write({
      id: x.id, referenceCode: x.referenceCode, uniqueReference: x.uniqueReference,
      userId: x.user?.publicId ?? x.userId,
      merchant: x.merchant?.name ?? '', currency: x.currency, amount: formatAmount(x.amountCents), status: x.status,
      bank: bankLabel(x.bankAccount), createdAt: x.createdAt.toISOString(),
      processedAt: processedDate ? processedDate.toISOString() : '',
      processingSeconds: processingSeconds ?? '',
      processedBy,
      receipt: x.receiptFile?.original ?? ''
    });
  }
  csv.end();
});

router.get('/export/deposits.xlsx', async (req: Request, res: Response) => {
  const { items } = await fetchPayments(req, 'DEPOSIT');
  const wb = new ExcelJS.Workbook(); const ws = wb.addWorksheet('Deposits');
  ws.columns = [
    { header: 'ID', key: 'id', width: 28 },{ header: 'Reference', key: 'referenceCode', width: 16 },
    { header: 'Unique Reference', key: 'uniqueReference', width: 20 },
    { header: 'User', key: 'userId', width: 16 },{ header: 'Merchant', key: 'merchant', width: 24 },
    { header: 'Currency', key: 'currency', width: 10 },{ header: 'Amount', key: 'amount', width: 14 },
    { header: 'Status', key: 'status', width: 12 },{ header: 'Bank', key: 'bank', width: 18 },
    { header: 'Created', key: 'createdAt', width: 22 },{ header: 'Processed', key: 'processedAt', width: 22 },
    { header: 'Processing (s)', key: 'processingSeconds', width: 16 },
    { header: 'Processed by', key: 'processedBy', width: 24 },
    { header: 'Receipt', key: 'receipt', width: 28 },
  ];
  items.forEach(x => {
    const { processedDate, processingSeconds, processedBy } = extractProcessingDetails(x);
    ws.addRow({
      id: x.id,
      referenceCode: x.referenceCode,
      uniqueReference: x.uniqueReference,
      userId: x.user?.publicId ?? x.userId,
      merchant: x.merchant?.name ?? '',
      currency: x.currency,
      amount: Number((x.amountCents / 100).toFixed(2)),
      status: x.status,
      bank: bankLabel(x.bankAccount),
      createdAt: x.createdAt,
      processedAt: processedDate,
      processingSeconds,
      processedBy,
      receipt: x.receiptFile?.original ?? ''
    });
  });
  res.setHeader('Content-Type','application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
  res.setHeader('Content-Disposition','attachment; filename="deposits.xlsx"');
  await wb.xlsx.write(res); res.end();
});

/* ---------------- Withdrawals ---------------- */
router.get('/report/withdrawals', async (req, res) => {
  const { total, items, page, perPage, pages, query } = await fetchPayments(req, 'WITHDRAWAL');
  res.render('admin-withdrawals', { title: 'Withdrawal requests', table: { total, items, page, perPage, pages }, query });
});

// DB-level filtering for PENDING so new items appear immediately
router.get('/report/withdrawals/pending', async (req, res) => {
  const [{ total, items, page, perPage, pages, query }, bankRows] = await Promise.all([
    fetchPayments(req, 'WITHDRAWAL', { status: 'PENDING,SUBMITTED' }),
    prisma.bankAccount.findMany({
      where: { active: true },
      orderBy: [{ method: 'asc' }, { bankName: 'asc' }, { createdAt: 'desc' }],
      select: { id: true, publicId: true, bankName: true, label: true, method: true },
    }),
  ]);

  const banks = bankRows.map((bank) => {
    const parts: string[] = [];
    if (bank.label) parts.push(bank.label);
    else if (bank.bankName) parts.push(bank.bankName);
    if (bank.publicId) parts.push(bank.publicId);
    const label = parts.length ? parts.join(' • ') : 'Unnamed bank';
    return {
      id: bank.id,
      label,
      method: (bank.method || '').toUpperCase(),
    };
  });

  res.render('admin-withdrawals-pending', {
    title: 'Pending withdrawal requests',
    table: { total, items, page, perPage, pages },
    query,
    banks,
    returnTo: req.originalUrl,
  });
});

router.post('/withdrawals/:id/approve', async (req, res) => {
  const id = req.params.id;
  const parsed = withdrawApproveSchema.safeParse(req.body ?? {});
  if (!parsed.success) {
    return res.status(400).json({ ok: false, error: 'Select a bank before approving' });
  }

  const pr = await prisma.paymentRequest.findUnique({ where: { id }, include: { merchant: true } });
  if (!pr || pr.type !== 'WITHDRAWAL' || !['PENDING', 'SUBMITTED'].includes(pr.status)) {
    return res.status(400).json({ ok: false, error: 'Invalid state' });
  }

  const redirectTarget = resolveReturnTo(parsed.data.returnTo, '/admin/report/withdrawals/pending');

  const method = ((pr.detailsJson as any)?.method || '').toString().toUpperCase();
  const bankAccount = await prisma.bankAccount.findFirst({
    where: { id: parsed.data.bankAccountId, active: true },
    select: { id: true, bankName: true, method: true },
  });

  if (!bankAccount) {
    return res.status(400).json({ ok: false, error: 'Selected bank is no longer available' });
  }

  const bankMethod = (bankAccount.method || '').toUpperCase();
  if (method && bankMethod && bankMethod !== method) {
    return res.status(400).json({ ok: false, error: 'Selected bank does not support this method' });
  }

  try {
    const result = await changePaymentStatus('WITHDRAWAL', {
      paymentId: id,
      targetStatus: 'APPROVED',
      actorAdminId: req.admin?.sub ?? null,
      bankAccountId: bankAccount.id,
    });
    const updated = result.payment;
    const merchantName = updated.merchant?.name || pr.merchant?.name || updated.merchantId;
    safeNotify(`✅ Withdrawal approved: ${updated.referenceCode} ${formatAmount(updated.amountCents)} ${updated.currency} (merchant ${merchantName})`).catch(() => {});
    res.json({ ok: true, redirect: redirectTarget });
  } catch (err) {
    if (err instanceof PaymentStatusError) {
      const message = err.code === 'INSUFFICIENT_FUNDS' ? 'Insufficient Balance' : err.message;
      return res.status(400).json({ ok: false, error: message });
    }
    console.error(err);
    res.status(500).json({ ok: false, error: 'Unable to update status' });
  }
});

router.post('/withdrawals/:id/reject', async (req, res) => {
  const id = req.params.id;
  const parsed = rejectBodySchema.safeParse(req.body ?? {});
  if (!parsed.success) {
    return res.status(400).json({ ok: false, error: 'Invalid payload' });
  }

  const comment = (parsed.data.comment || parsed.data.reason || '').trim();
  if (!comment) {
    return res.status(400).json({ ok: false, error: 'Comment is required' });
  }

  const pr = await prisma.paymentRequest.findUnique({ where: { id }, include: { merchant: true } });
  if (!pr || pr.type !== 'WITHDRAWAL' || !['PENDING', 'SUBMITTED'].includes(pr.status)) {
    return res.status(400).json({ ok: false, error: 'Invalid state' });
  }

  const redirectTarget = resolveReturnTo(parsed.data.returnTo, '/admin/report/withdrawals/pending');
  try {
    const result = await changePaymentStatus('WITHDRAWAL', {
      paymentId: id,
      targetStatus: 'REJECTED',
      actorAdminId: req.admin?.sub ?? null,
      comment,
    });
    const updated = result.payment;
    const merchantName = updated.merchant?.name || pr.merchant?.name || updated.merchantId;
    safeNotify(`⛔ Withdrawal rejected: ${updated.referenceCode} ${formatAmount(updated.amountCents)} ${updated.currency} — ${comment}`).catch(() => {});
    res.json({ ok: true, redirect: redirectTarget });
  } catch (err) {
    if (err instanceof PaymentStatusError) {
      const message = err.code === 'INSUFFICIENT_FUNDS' ? 'Insufficient Balance' : err.message;
      return res.status(400).json({ ok: false, error: message });
    }
    console.error(err);
    res.status(500).json({ ok: false, error: 'Unable to update status' });
  }
});

router.post('/withdrawals/:id/status', async (req, res) => {
  const id = req.params.id;
  const parsed = statusChangeSchema.safeParse(req.body ?? {});
  if (!parsed.success) {
    return res.status(400).json({ ok: false, error: 'Invalid payload' });
  }

  const payload = parsed.data;
  const payment = await prisma.paymentRequest.findUnique({ where: { id }, include: { merchant: true } });
  if (!payment || payment.type !== 'WITHDRAWAL') {
    return res.status(404).json({ ok: false, error: 'Payment not found' });
  }

  const comment = (payload.comment || '').trim();
  const amountInfo = readAmountInput(payload);
  if (amountInfo.error) {
    return res.status(400).json({ ok: false, error: amountInfo.error });
  }

  if (payload.targetStatus === 'REJECTED' && !comment) {
    return res.status(400).json({ ok: false, error: 'Comment is required' });
  }

  try {
    const result = await changePaymentStatus('WITHDRAWAL', {
      paymentId: id,
      targetStatus: payload.targetStatus,
      actorAdminId: req.admin?.sub ?? null,
      amountCents: payload.targetStatus === 'APPROVED'
        ? (amountInfo.provided ? amountInfo.cents ?? null : null)
        : null,
      comment,
    });
    const updated = result.payment;
    const merchantName = updated.merchant?.name || payment.merchant?.name || updated.merchantId;
    const prefix = payload.targetStatus === 'APPROVED' ? '✅' : '⛔';
    const verb = payload.targetStatus === 'APPROVED' ? 'approved' : 'rejected';
    const suffix = comment ? ` — ${comment}` : '';
    safeNotify(`${prefix} Withdrawal ${verb}: ${updated.referenceCode} ${formatAmount(updated.amountCents)} ${updated.currency} (merchant ${merchantName})${suffix}`).catch(() => {});
    res.json({ ok: true, status: updated.status, amountCents: updated.amountCents });
  } catch (err) {
    if (err instanceof PaymentStatusError) {
      const message = err.code === 'INSUFFICIENT_FUNDS' ? 'Insufficient Balance' : err.message;
      return res.status(400).json({ ok: false, error: message });
    }
    console.error(err);
    res.status(500).json({ ok: false, error: 'Unable to update status' });
  }
});

router.post('/export/withdrawals', async (req: Request, res: Response) => {
  try {
    const format = parseExportFormat(req.body?.type);
    const filters = coerceExportFilters(req.body?.filters);
    const columns = sanitizeColumns(req.body?.columns, ADMIN_WITHDRAWAL_EXPORT_COLUMNS);
    const { items } = await fetchPaymentsFromQuery(filters, 'WITHDRAWAL');
    const timezone = resolveTimezone((req as any).activeTimezone || res.locals.timezone);
    const file = await buildPaymentExportFile({
      format,
      columns,
      items: items as unknown as PaymentExportItem[],
      context: { scope: 'admin', type: 'WITHDRAWAL' },
      timezone,
    });
    res.setHeader('Content-Type', file.contentType);
    res.setHeader('Content-Disposition', `attachment; filename="${file.filename}"`);
    res.send(file.body);
  } catch (err) {
    console.error(err);
    res.status(500).json({ ok: false, error: 'Unable to export withdrawals' });
  }
});

router.get('/export/withdrawals.csv', async (req: Request, res: Response) => {
  const { items } = await fetchPayments(req, 'WITHDRAWAL');
  res.setHeader('Content-Type', 'text/csv');
  res.setHeader('Content-Disposition', 'attachment; filename="withdrawals.csv"');
  const csv = stringify({
    header: true,
    columns: ['id','referenceCode','uniqueReference','userId','merchant','currency','amount','status','bank','createdAt','processedAt','processingSeconds','processedBy']
  });
  csv.pipe(res);
  for (const x of items) {
    const { processedDate, processingSeconds, processedBy } = extractProcessingDetails(x);
    csv.write({
      id: x.id, referenceCode: x.referenceCode, uniqueReference: x.uniqueReference,
      userId: x.user?.publicId ?? x.userId,
      merchant: x.merchant?.name ?? '', currency: x.currency, amount: formatAmount(x.amountCents), status: x.status,
      bank: bankLabel(x.bankAccount), createdAt: x.createdAt.toISOString(),
      processedAt: processedDate ? processedDate.toISOString() : '',
      processingSeconds: processingSeconds ?? '',
      processedBy
    });
  }
  csv.end();
});

router.get('/export/withdrawals.xlsx', async (req: Request, res: Response) => {
  const { items } = await fetchPayments(req, 'WITHDRAWAL');
  const wb = new ExcelJS.Workbook(); const ws = wb.addWorksheet('Withdrawals');
  ws.columns = [
    { header: 'ID', key: 'id', width: 28 },{ header: 'Reference', key: 'referenceCode', width: 16 },
    { header: 'Unique Reference', key: 'uniqueReference', width: 20 },
    { header: 'User', key: 'userId', width: 16 },{ header: 'Merchant', key: 'merchant', width: 24 },
    { header: 'Currency', key: 'currency', width: 10 },{ header: 'Amount', key: 'amount', width: 14 },
    { header: 'Status', key: 'status', width: 12 },{ header: 'Bank', key: 'bank', width: 18 },
    { header: 'Created', key: 'createdAt', width: 22 },{ header: 'Processed', key: 'processedAt', width: 22 },
    { header: 'Processing (s)', key: 'processingSeconds', width: 16 },
    { header: 'Processed by', key: 'processedBy', width: 24 },
  ];
  items.forEach(x => {
    const { processedDate, processingSeconds, processedBy } = extractProcessingDetails(x);
    ws.addRow({
      id: x.id,
      referenceCode: x.referenceCode,
      uniqueReference: x.uniqueReference,
      userId: x.user?.publicId ?? x.userId,
      merchant: x.merchant?.name ?? '',
      currency: x.currency,
      amount: Number((x.amountCents / 100).toFixed(2)),
      status: x.status,
      bank: bankLabel(x.bankAccount),
      createdAt: x.createdAt,
      processedAt: processedDate,
      processingSeconds,
      processedBy,
    });
  });
  res.setHeader('Content-Type','application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
  res.setHeader('Content-Disposition','attachment; filename="withdrawals.xlsx"');
  await wb.xlsx.write(res); res.end();
});

/* ---------------- Clients ---------------- */
router.get('/users', async (req, res) => {
  if (!adminCanViewUsers(req)) {
    return res.status(403).render('admin-users-disabled', { title: 'Clients' });
  }
  const { query, merchants, merchantIds } = await resolveUserDirectoryInput(req);
  const table = merchantIds.length
    ? await getUserDirectory({ merchantIds, search: query.q || null, page: query.page, perPage: query.perPage })
    : { total: 0, page: 1, perPage: 25, pages: 1, items: [] };

  res.render('admin-users', {
    title: 'Clients',
    table,
    query,
    merchants,
  });
});

router.get('/export/users.csv', async (req: Request, res: Response) => {
  if (!adminCanViewUsers(req)) {
    return res.sendStatus(403);
  }
  const { query, merchantIds } = await resolveUserDirectoryInput(req);
  const items = await collectUsersForExport(merchantIds, query.q || null);
  res.setHeader('Content-Type', 'text/csv');
  res.setHeader('Content-Disposition', 'attachment; filename="clients.csv"');
  const csv = stringify({
    header: true,
    columns: ['userId','fullName','email','phone','verificationStatus','clientStatus','registeredAt','lastActivity','totalDeposits','totalWithdrawals','merchants','latestSessionId'],
  });
  csv.pipe(res);
  items.forEach((user) => {
    csv.write({
      userId: user.publicId,
      fullName: user.fullName || '',
      email: user.email || '',
      phone: user.phone || '',
      verificationStatus: user.verificationStatus,
      clientStatus: formatClientStatusLabel(user.clientStatus),
      registeredAt: user.registeredAt.toISOString(),
      lastActivity: user.lastActivityAt ? user.lastActivityAt.toISOString() : '',
      totalDeposits: user.totalApprovedDeposits,
      totalWithdrawals: user.totalApprovedWithdrawals,
      merchants: user.merchants.map((m) => m.name).join(', '),
      latestSessionId: user.latestSessionId || '',
    });
  });
  csv.end();
});

router.get('/export/users.xlsx', async (req: Request, res: Response) => {
  if (!adminCanViewUsers(req)) {
    return res.sendStatus(403);
  }
  const { query, merchantIds } = await resolveUserDirectoryInput(req);
  const items = await collectUsersForExport(merchantIds, query.q || null);
  const wb = new ExcelJS.Workbook();
  const ws = wb.addWorksheet('Clients');
  ws.columns = [
    { header: 'User ID', key: 'userId', width: 16 },
    { header: 'Full name', key: 'fullName', width: 24 },
    { header: 'Email', key: 'email', width: 24 },
    { header: 'Phone', key: 'phone', width: 18 },
    { header: 'Verification status', key: 'status', width: 18 },
    { header: 'Client status', key: 'clientStatus', width: 16 },
    { header: 'Registered', key: 'registeredAt', width: 24 },
    { header: 'Last activity', key: 'lastActivity', width: 24 },
    { header: 'Total deposits', key: 'totalDeposits', width: 18 },
    { header: 'Total withdrawals', key: 'totalWithdrawals', width: 20 },
    { header: 'Merchants', key: 'merchants', width: 32 },
    { header: 'Latest Session ID', key: 'latestSessionId', width: 28 },
  ];
  items.forEach((user) => {
    ws.addRow({
      userId: user.publicId,
      fullName: user.fullName || '',
      email: user.email || '',
      phone: user.phone || '',
      status: user.verificationStatus,
      clientStatus: formatClientStatusLabel(user.clientStatus),
      registeredAt: user.registeredAt,
      lastActivity: user.lastActivityAt,
      totalDeposits: user.totalApprovedDeposits,
      totalWithdrawals: user.totalApprovedWithdrawals,
      merchants: user.merchants.map((m) => m.name).join(', '),
      latestSessionId: user.latestSessionId || '',
    });
  });
  res.setHeader('Content-Type','application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
  res.setHeader('Content-Disposition','attachment; filename="clients.xlsx"');
  await wb.xlsx.write(res); res.end();
});

router.get('/export/users.pdf', async (req: Request, res: Response) => {
  if (!adminCanViewUsers(req)) {
    return res.sendStatus(403);
  }
  const { query, merchantIds } = await resolveUserDirectoryInput(req);
  const items = await collectUsersForExport(merchantIds, query.q || null);
  const pdf = renderUserDirectoryPdf(items);
  res.setHeader('Content-Type', 'application/pdf');
  res.setHeader('Content-Disposition', 'attachment; filename="clients.pdf"');
  res.end(pdf);
});

/* ---------------- Banks ---------------- */
router.get('/bank-transfer/banks', async (_req, res) => {
  const banks = await prisma.bankAccount.findMany({ orderBy: { createdAt: 'desc' } });
  res.render('admin-banks', { title: 'List of banks', banks });
});

router.get('/bank-transfer/banks/:id/edit', async (req, res) => {
  const bank = await prisma.bankAccount.findUnique({ where: { id: req.params.id } });
  if (!bank) return res.status(404).send('Not found');
  res.render('admin-bank-edit', { title: 'Edit bank', bank });
});

router.post('/bank-transfer/banks/:id/edit', async (req, res) => {
  const id = req.params.id;
  const data: any = {
    holderName: req.body.holderName,
    bankName: req.body.bankName,
    accountNo: req.body.accountNo,
    iban: req.body.iban || null,
    currency: req.body.currency,
    instructions: req.body.instructions || null,
    active: req.body.active === 'on'
  };
  await prisma.bankAccount.update({ where: { id }, data });
  res.redirect('/admin/bank-transfer/banks');
});

export const adminRouter = router;