// apps/server/src/routes/twofa-extra.ts
import { Router } from 'express';
export const twofaRouter = Router(); // intentionally empty – all 2FA lives in auth.ts now