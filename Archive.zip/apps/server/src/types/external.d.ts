declare module 'bcryptjs';
declare module 'speakeasy';
declare module 'qrcode';
declare module 'ejs-mate';
